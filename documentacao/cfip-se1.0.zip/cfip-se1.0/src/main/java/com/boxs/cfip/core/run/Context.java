package com.boxs.cfip.core.run;

import java.text.DateFormat;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.boxs.cfip.core.config.PersistenceConfig;
import com.boxs.cfip.core.dao.EntidadesNew;
import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Lancamento;
import com.boxs.cfip.core.model.TipoMovimento;
import com.boxs.cfip.core.model.Usuario;

import client.ss.infraestrutura.util.Texto;

public class Context {
	// https://medium.com/movile-tech/trocar-o-java-pelo-kotlin-8bed76014d99
	// http://shengwangi.blogspot.com.br/2016/02/response-for-get-post-put-delete-in-rest.html
	private static Logger LOG = Logger.getLogger(Context.class.getName());
	private static Entidades entidadesOld;
	private static EntidadesNew entidades;
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = null;
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
		try {
			System.out.println(Texto.md5("gleyson sampaio 1234 #$@$;/"));
			context = new AnnotationConfigApplicationContext(PersistenceConfig.class);
			entidadesOld = context.getBean(Entidades.class);
			entidades = context.getBean(EntidadesNew.class);
			imprimeLista("CONTAS",entidades.listarContas(1));
			/*//imprimeLista("CONTAS",entidades.listarContas(1));
			//imprimeLista("NATUREZAS",entidades.listarNaturezas(1));
			GregorianCalendar  gc  =new GregorianCalendar(2018, 7, 1);
			Date de = gc.getTime();
			gc.add(Calendar.DAY_OF_MONTH, 30);
			Date ate = gc.getTime();
			imprimeLista("LANCAMENTOS",entidades.listarPrevisoes(3, de, ate, null, null));
			//criarUsuario();
*/		} catch (Exception e) {
			System.err.println("Algum erro");
			e.printStackTrace();
		}
	}
	private static void imprimeLista(String entidade, List lista) {
		System.out.println("LISTANDO: " + entidade);
		for(Object item: lista) {
			System.out.println(item);
		}
		System.out.println("A consulta retornou: " + lista.size() + " Registros\n\n");
	}
	private static void criarUsuario() {
		Usuario usuario = new Usuario();
		usuario.setEmail("gleyson.s@hotmail.com");
		usuario.setNome("Gleyson");
		usuario.setSenha("1234");
		entidadesOld.incluirUsuario(usuario);
		System.out.println("Salvou usuario");
	}

	private static void lancarReceitaConta1(Double valor) {
		
		Lancamento lanc = new Lancamento();
		lanc.setConta(1);
		lanc.setNatureza(1);
		// lanc.setPrevisto(false);
		lanc.setUsuario(1);
		lanc.setTipoMovimento(TipoMovimento.CREDITO);
		lanc.setValor(valor);
		lanc.setDescricao("Lançamento de Credito");
	}
}
