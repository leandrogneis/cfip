package com.boxs.cfip.core.model.vo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

import com.boxs.cfip.core.model.TipoMovimento;

public class LancamentoVo implements Serializable {
	private Integer id;
	private String conta;
	private String descricao;
	private Double saldoInicial;
	private Double valor;
	private Double saldoFinal;
	
	private TipoMovimento tipo;
	private String sigla;
	private Date data;
	private boolean previsao;
	private Date quitacao;
	private String natureza;
	
	private Integer periodo;
	private Integer periodoQuitacao;
	
	private boolean tranferencia;
	private Integer origemCredito;
	private String contato;
	public LancamentoVo(Integer id, Date data, String conta,String natureza, String descricao, Double saldoInicial, Double valor,Double saldoFinal,
			TipoMovimento tipoMovimento, boolean previsao,Date quitacao,Integer periodo,Integer periodoQuitacao,
			boolean tranferencia,Integer origemCredito,String contato) {
		super();
		this.data = data;
		this.conta = conta;
		this.descricao = descricao;
		this.saldoFinal = saldoFinal;
		this.saldoInicial = saldoInicial;
		this.valor=valor;
		this.tipo = tipoMovimento;
		this.sigla = this.tipo.toString().substring(0, 1);
		this.previsao = previsao;
		this.natureza=natureza;
		this.quitacao=quitacao;
		this.id=id;
		this.periodo=periodo;
		this.periodoQuitacao=periodoQuitacao;
		this.tranferencia=tranferencia;
		this.origemCredito=origemCredito;
		this.contato=""; // FIXME: Ajustar a consulta
	}
	
	public Integer getOrigemCredito() {
		return origemCredito;
	}
	public String getContato() {
		return contato;
	}
	public String getConta() {
		return conta;
	}
	public boolean isTranferencia() {
		return tranferencia;
	}
	public Date getQuitacao() {
		return quitacao;
	}
	public String getDescricao() {
		return descricao;
	}
	
	public TipoMovimento getTipo() {
		return tipo;
	}
	public Date getData() {
		return data;
	}
	public String getNatureza() {
		return natureza;
	}
	public boolean isPrevisao() {
		return previsao;
	}
	
	public String getSigla() {
		return sigla;
	}
	public Integer getId() {
		return id;
	}
	public Double getValor() {
		return valor;
	}
	public Double getSaldoInicial() {
		return saldoInicial;
	}
	public Double getSaldoFinal() {
		return saldoFinal;
	}
	public Integer getPeriodo() {
		return periodo;
	}
	public Integer getPeriodoQuitacao() {
		return periodoQuitacao;
	}
}
