package com.boxs.cfip.core.run;

import org.hsqldb.util.DatabaseManagerSwing;

public class HSQLDB {
	public static void main(String[] args) {
		DatabaseManagerSwing.main(new String[] { "--url", "jdbc:hsqldb:file:/cfip/database/cfipdb", "--user", "sa", "--password", ""});
	}
}
