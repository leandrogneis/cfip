package com.boxs.cfip.core.model.vo;

import java.util.List;

import com.boxs.cfip.core.model.Saldo;

public class ExtradoVo {
	private Saldo saldo;
	private List<LancamentoVo> lancamentos;
	public Saldo getSaldo() {
		return saldo;
	}
	public void setSaldo(Saldo saldo) {
		this.saldo = saldo;
	}
	public List<LancamentoVo> getLancamentos() {
		return lancamentos;
	}
	public void setLancamentos(List<LancamentoVo> lancamentos) {
		this.lancamentos = lancamentos;
	}
}
