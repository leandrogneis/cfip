package com.boxs.cfip.core.util;

public enum TipoOperacao {
	INCLUSAO,
	ALTERACAO
}
