package com.boxs.cfip.core.util;

import java.text.MessageFormat;
import java.util.Date;
import java.util.Locale;

public class MyMessageFormat {
	static Date data = new Date();
	static Double salario = 1234.567;
	static String nome = "GLEYSON SAMPAIO";
	
	public static void main(String[] args) {
		//No dia {data} às {data}, o colaborador {nome} recebeu {salario} reais.
		String msg = "No dia {0,date} e {0,time}, o colaborador {1} recebeu {2} reais";
		MessageFormat mf = new MessageFormat(msg, Locale.US);
		
		System.out.println(mf.format(new Object[] {data, nome,salario}));

		
	}
}
