package client.ss.desktop;

public enum PosicaoRotulo {
    ESQUERDA,
    TOPO;    
}
