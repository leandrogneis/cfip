package client.ss.desktop.evento;

import java.util.EventListener;


public interface ValidacaoListener  extends EventListener {
    public void validacaoListener(ValidacaoEvento evento);
}
