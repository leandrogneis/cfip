package client.ss.desktop.evento;

import java.util.EventListener;


public interface AlteracaoListener extends EventListener {
    public void alteracaoListener(AlteracaoEvento evento);
}
