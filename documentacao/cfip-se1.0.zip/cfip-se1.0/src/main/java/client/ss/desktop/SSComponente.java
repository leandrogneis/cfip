package client.ss.desktop;

public interface SSComponente {
}
