package client.ss.desktop.evento;

import java.awt.AWTEvent;


public class PesquisaEvento extends AWTEvent {    
    public PesquisaEvento(Object source) {
        super(source, 200802);        
    }
}
