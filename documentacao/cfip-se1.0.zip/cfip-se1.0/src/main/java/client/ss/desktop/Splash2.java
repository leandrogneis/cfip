package client.ss.desktop;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import client.ss.desktop.imagens.Imagem;

public class Splash2 extends JFrame {
	private JLabel logotipo;
	public Splash2() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		getContentPane().setLayout(gridBagLayout);
		logotipo = new JLabel(Imagem.jpg("cfip", "splash"));
		GridBagConstraints gbc_logotipo = new GridBagConstraints();
		gbc_logotipo.insets = new Insets(2, 2, 2, 2);
		gbc_logotipo.weighty = 1.0;
		gbc_logotipo.fill = GridBagConstraints.BOTH;
		gbc_logotipo.ipady = 1;
		gbc_logotipo.weightx = 1.0;
		gbc_logotipo.gridx = 0;
		gbc_logotipo.gridy = 0;
		getContentPane().add(logotipo, gbc_logotipo);
		
		JLabel versao = new JLabel("Vers\u00E3o: 2018-02-01 - Desenvolvido por: BOX Solutions");
		versao.setFont(new Font("Tahoma", Font.BOLD, 11));
		versao.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_versao = new GridBagConstraints();
		gbc_versao.insets = new Insets(0, 0, 2, 0);
		gbc_versao.anchor = GridBagConstraints.NORTHWEST;
		gbc_versao.fill = GridBagConstraints.BOTH;
		gbc_versao.gridx = 0;
		gbc_versao.gridy = 1;
		getContentPane().add(versao, gbc_versao);
		setSize(400,350);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);
		setVisible(true);
		setLocationRelativeTo(null);
		

	}
}