package client.ss.desktop;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import client.ss.desktop.imagens.Imagem;
import java.awt.BorderLayout;
import java.awt.Color;

public class Splash extends JFrame {
	private JLabel logotipo;
	public Splash() {
		
		logotipo = new JLabel(Imagem.jpg("cfip", "splash"));
		getContentPane().add(logotipo, BorderLayout.CENTER);
		logotipo.setBorder(BorderFactory.createEtchedBorder());
		JLabel lblVersao = new JLabel("CFIP - Versão: 1.0 - 201802.16 - Desenvolvido por: BOX Solutions");
		lblVersao.setBorder(BorderFactory.createEtchedBorder());
		lblVersao.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblVersao.setForeground(Color.BLUE);
		lblVersao.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(lblVersao, BorderLayout.SOUTH);
		setSize(400,300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);
		setVisible(true);
		setLocationRelativeTo(null);
	}
}