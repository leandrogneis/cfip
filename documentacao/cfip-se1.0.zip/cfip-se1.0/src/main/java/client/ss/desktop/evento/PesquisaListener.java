package client.ss.desktop.evento;

import java.util.EventListener;


public interface PesquisaListener extends EventListener {
    public void pesquisaListener(PesquisaEvento evento);
}
