package client.ss.desktop;


public class Relatorio {
    
}
