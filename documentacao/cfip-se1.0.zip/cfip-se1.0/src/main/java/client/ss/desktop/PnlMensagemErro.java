package client.ss.desktop;

import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JLabel;
import javax.swing.JPanel;


public class PnlMensagemErro extends JPanel {
    private JLabel jLabel1 = new JLabel();

    public PnlMensagemErro() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout( null );
        this.setSize(new Dimension(388, 164));
        jLabel1.setText("jLabel1");
        jLabel1.setBounds(new Rectangle(25, 0, 340, 40));
        this.add(jLabel1, null);
    }
}
