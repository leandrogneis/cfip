package client.desktop.app;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Fatura;
import com.boxs.cfip.core.model.Lancamento;
import com.boxs.cfip.core.model.vo.LancamentoVo;
import com.boxs.cfip.core.util.Formato;
import com.boxs.cfip.core.util.Total;

import client.desktop.util.Formulario;
import client.ss.desktop.Mensagem;
import client.ss.desktop.PosicaoRotulo;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCampoDataHora;
import client.ss.desktop.SSCampoNumero;
import client.ss.desktop.SSCampoTexto;
import client.ss.desktop.SSGrade;
import client.ss.desktop.tabela.TipoSelecao;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FrmFaturaDetalhe extends Formulario {
	// rodape
	private SSBotao cmdCompensar = new SSBotao();
	private SSBotao cmdAdicionar = new SSBotao();
	private SSBotao cmdRemover = new SSBotao();
	private SSBotao cmdFechar = new SSBotao();
	private SSGrade grid = new SSGrade();
	private JScrollPane scroll = new JScrollPane();
	// DAOs - NAO OFICIAL
	@Autowired
	private Entidades dao;

	private SSCampoDataHora txtData = new SSCampoDataHora();
	private SSCampoTexto txtSigla = new SSCampoTexto();
	private SSCampoTexto txtDetalhe = new SSCampoTexto();

	//
	private Total total = new Total();
	private Fatura entidade;
	private SSCampoNumero txtDespesas = new SSCampoNumero();
	private SSCampoNumero txtReceitas = new SSCampoNumero();
	private SSCampoNumero txtSaldoAtual = new SSCampoNumero();
	//

	public FrmFaturaDetalhe() {
		init();
	}

	private void init() {
		super.setTitulo("Detalhe da Fatura");
		super.setDescricao("Listagem dos lançamentos de uma fatura");
		super.botoesNaEsquerda();
		super.addBotaoRodape(cmdAdicionar);
		super.addBotaoRodape(cmdRemover);
		super.addBotaoRodape(cmdCompensar);
		super.addBotaoRodape(cmdFechar);
		// implementando o conteudo do formulario
		JPanel conteudo = super.getConteudoTabela();

		// usando o painel de conteudo
		JPanel painelFiltro = new JPanel();
		conteudo.add(painelFiltro, BorderLayout.NORTH);
		grid.setTipoSelecao(TipoSelecao.SELECAO_MULTIPLA);
		scroll.setViewportView(grid);
		JPanel pnlDesc = new JPanel(new BorderLayout());
		pnlDesc.add(scroll, BorderLayout.CENTER);
		conteudo.add(pnlDesc, BorderLayout.CENTER);
		grid.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent event) {

			}
		});

		GridBagLayout gbl_painelFiltro = new GridBagLayout();
		painelFiltro.setLayout(gbl_painelFiltro);
		painelFiltro.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		grid.getModeloTabela().addColumn("Data");
		grid.getModeloTabela().addColumn("Previsão");
		grid.getModeloTabela().addColumn("Conta");
		grid.getModeloTabela().addColumn("Natureza");
		grid.getModeloTabela().addColumn("Valor");
		grid.getModeloColuna().getColumn(0).setPreferredWidth(70);
		grid.getModeloColuna().getColumn(1).setPreferredWidth(70);
		grid.getModeloColuna().getColumn(2).setPreferredWidth(125);
		grid.getModeloColuna().getColumn(3).setPreferredWidth(125);
		grid.getModeloColuna().setCampo(0, "data");
		grid.getModeloColuna().setFormato(0, "dd/MM/yy");
		grid.getModeloColuna().setCampo(1, "quitacao");
		grid.getModeloColuna().setFormato(1, "dd/MM/yy");
		grid.getModeloColuna().setCampo(2, "conta");
		grid.getModeloColuna().setCampo(3, "natureza");
		grid.getModeloColuna().setCampo(4, "valor");
		grid.getModeloColuna().setFormato(4, Formato.MOEDA);
		grid.getModeloColuna().definirPositivoNegativo(4);

		cmdCompensar.setText("Fechar Fatura");

		cmdFechar.setText("Fechar");
		cmdCompensar.setIcone("barcode");

		GridBagConstraints gbc_txtDataDe = new GridBagConstraints();
		gbc_txtDataDe.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDataDe.insets = new Insets(5, 5, 5, 0);
		gbc_txtDataDe.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDataDe.gridx = 0;
		gbc_txtDataDe.gridy = 0;
		txtData.setComponenteCorFonte(Color.BLUE);
		txtData.setComponenteNegrito(true);
		txtData.setEditavel(false);
		txtData.setColunas(8);
		txtData.setRotulo("Vencimento");
		painelFiltro.add(txtData, gbc_txtDataDe);

		GridBagConstraints gbc_txtDataAte = new GridBagConstraints();
		gbc_txtDataAte.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDataAte.insets = new Insets(5, 5, 5, 0);
		gbc_txtDataAte.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDataAte.gridx = 1;
		gbc_txtDataAte.gridy = 0;
		txtSigla.setComponenteCorFonte(Color.BLUE);
		txtSigla.setComponenteNegrito(true);
		txtSigla.setEditavel(false);
		txtSigla.setColunas(8);
		txtSigla.setRotulo("Sigla");
		painelFiltro.add(txtSigla, gbc_txtDataAte);

		GridBagConstraints gbc_txtDetalhe = new GridBagConstraints();
		gbc_txtDetalhe.weightx = 1.0;
		gbc_txtDetalhe.weighty = 1.0;
		gbc_txtDetalhe.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDetalhe.insets = new Insets(5, 5, 5, 5);
		gbc_txtDetalhe.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDetalhe.gridx = 2;
		gbc_txtDetalhe.gridy = 0;
		txtDetalhe.setComponenteNegrito(true);
		txtDetalhe.setComponenteCorFonte(Color.BLUE);
		txtDetalhe.setEditavel(false);
		txtDetalhe.setRotulo("Descrição");
		painelFiltro.add(txtDetalhe, gbc_txtDetalhe);

		cmdFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sair();
			}
		});
		cmdCompensar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				compensar();
			}
		});

		//
		FlowLayout pnlSaldoLayout = new FlowLayout();
		pnlSaldoLayout.setAlignment(FlowLayout.RIGHT);
		JPanel pnlSaldo = new JPanel(pnlSaldoLayout);
		pnlSaldo.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));

		pnlDesc.add(pnlSaldo, BorderLayout.SOUTH);
		txtDespesas.setComponenteCorFonte(Color.RED);
		txtDespesas.setComponenteNegrito(true);
		txtDespesas.setEditavel(false);
		txtDespesas.setColunas(6);
		txtDespesas.setRotuloPosicao(PosicaoRotulo.ESQUERDA);
		txtDespesas.setRotulo("Despesa");
		txtReceitas.setComponenteNegrito(true);
		txtReceitas.setComponenteCorFonte(Color.BLUE);

		txtReceitas.setEditavel(false);
		txtReceitas.setColunas(6);
		txtReceitas.setRotuloPosicao(PosicaoRotulo.ESQUERDA);
		txtReceitas.setRotulo("Receita");
		txtSaldoAtual.setComponenteNegrito(true);
		txtSaldoAtual.setComponenteCorFonte(Color.BLUE);

		txtSaldoAtual.setEditavel(false);
		txtSaldoAtual.setColunas(6);
		txtSaldoAtual.setRotuloPosicao(PosicaoRotulo.ESQUERDA);
		txtSaldoAtual.setRotulo("Saldo");

		txtDespesas.setFormato(Formato.MOEDA);
		txtSaldoAtual.setFormato(Formato.MOEDA);
		txtReceitas.setFormato(Formato.MOEDA);

		pnlSaldo.add(txtReceitas);
		pnlSaldo.add(txtDespesas);
		pnlSaldo.add(txtSaldoAtual);
		txtReceitas.setComponenteCorFonte(Color.BLUE);
		txtDespesas.setComponenteCorFonte(Color.RED);
		cmdAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				adicionar();
			}
		});
		
		cmdAdicionar.setText("Adicionar");
		cmdRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				remover();
			}
		});
		cmdRemover.setText("Remover");
	}

	public void setEntidade(Fatura entidade) {
		this.entidade = entidade;
		txtData.setDataHora(entidade.getVencimento());
		txtDetalhe.setText(entidade.getDetalhe());
		txtSigla.setText(entidade.getSigla());
	}

	private void sair() {
		super.retornar();
	}
	private void compensar() {
		if(Mensagem.pergunta("Deseja fechar esta fatura?")) {
			dao.fecharFatura(entidade.getId());
			Mensagem.informa("Fatura fechada com sucesso!!");
		}
	}
	private void adicionar() {
		FrmPrevisoesDialog dlg = getBean(FrmPrevisoesDialog.class);
		LancamentoVo lancto = (LancamentoVo) this.exibirDialogo(dlg);
		if(lancto!=null) {
			if(Mensagem.pergunta("Confirma incluir este lançamento na fatura?")){
				Lancamento lancamento = dao.buscar(Lancamento.class, lancto.getId());
				lancamento.setFatura(entidade.getId());
				dao.alterar(lancamento);
				listar();
			}
		}
	}
	private void remover() {
		LancamentoVo lancto = (LancamentoVo) grid.getLinhaSelecionada();
		if(lancto!=null) {
			if(Mensagem.pergunta("Confirma remover o lançamento da fatura")) {
				dao.removerFaturaLancamento(lancto.getId());
				listar();
			}
		}else
			Mensagem.avisa("Selecione um lançamento");
	}
	private void listar() {
		try {
			List<LancamentoVo> lista = new ArrayList<LancamentoVo>();
			lista = dao.listarFaturaLancamentos(entidade.getUsuario(), entidade.getId());
			if(lista.size()==0)
				Mensagem.avisa("Nenhum dado encontrado");
			
			grid.setValue(lista);
			total = dao.totais(lista);
			txtSaldoAtual.setValue(total.getSaldo());
			txtSaldoAtual.setComponenteCorFonte(total.getSaldo() < 0.0d ? Color.RED: Color.BLUE);
			txtDespesas.setValue(total.getDebito());
			txtReceitas.setValue(total.getCredito());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void load() {
		listar();
	}
}
