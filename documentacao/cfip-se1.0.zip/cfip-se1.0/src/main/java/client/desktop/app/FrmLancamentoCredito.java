package client.desktop.app;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Conta;
import com.boxs.cfip.core.model.Lancamento;
import com.boxs.cfip.core.model.Natureza;
import com.boxs.cfip.core.model.TipoMovimento;
import com.boxs.cfip.core.util.Formato;

import client.desktop.util.Formulario;
import client.ss.desktop.Mensagem;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCaixaCombinacao;
import client.ss.desktop.SSCampoDataHora;
import client.ss.desktop.SSCampoNumero;
import client.ss.desktop.SSCampoTexto;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)	
public class FrmLancamentoCredito extends Formulario {
	private SSCampoDataHora txtData = new SSCampoDataHora();
	private SSCampoNumero txtValor = new SSCampoNumero();
	private SSCampoTexto txtDescricao = new SSCampoTexto();
	
	private SSBotao cmdSalvar = new SSBotao();
	private SSBotao cmdSair = new SSBotao();
	private Lancamento entidade;
	@Autowired
	private Entidades dao;
	private SSCaixaCombinacao cboConta = new SSCaixaCombinacao();
	private SSCaixaCombinacao cboNatureza = new SSCaixaCombinacao();
	private JCheckBox chkNovo = new JCheckBox("Novo?");
	public FrmLancamentoCredito() {
		init();
	}
	private void init() {
		// HERANÇA
		super.setTitulo("Receitas");
		super.setDescricao("Lançamento de créditos e receitas");
		super.addComponente(chkNovo);
		super.addBotaoRodape(cmdSalvar);
		super.addBotaoRodape(cmdSair);
		
		// IMPORTANTE
		JPanel panelCampos = super.getConteudoGrid();
		panelCampos.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		GridBagLayout gbl_panelCampos = new GridBagLayout();
		panelCampos.setLayout(gbl_panelCampos);

		GridBagConstraints gbc_txtData = new GridBagConstraints();
		gbc_txtData.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtData.anchor = GridBagConstraints.WEST;
		gbc_txtData.insets = new Insets(5, 5, 0, 5);
		gbc_txtData.gridx = 0;
		gbc_txtData.gridy = 0;
		txtData.setColunas(15);
		panelCampos.add(txtData, gbc_txtData);
		
		GridBagConstraints gbc_cboConta = new GridBagConstraints();
		gbc_cboConta.insets = new Insets(5, 5, 0, 5);
		gbc_cboConta.fill = GridBagConstraints.BOTH;
		gbc_cboConta.gridx = 0;
		gbc_cboConta.gridy = 1;
		cboConta.setRotulo("Conta");
		panelCampos.add(cboConta, gbc_cboConta);
		
		GridBagConstraints gbc_cboNatureza = new GridBagConstraints();
		gbc_cboNatureza.insets = new Insets(5, 5, 0, 5);
		gbc_cboNatureza.fill = GridBagConstraints.BOTH;
		gbc_cboNatureza.gridx = 0;
		gbc_cboNatureza.gridy = 2;
		cboNatureza.setRotulo("Natureza");
		panelCampos.add(cboNatureza, gbc_cboNatureza);

		GridBagConstraints gbc_txtValor = new GridBagConstraints();
		gbc_txtValor.weightx = 2.0;
		gbc_txtValor.insets = new Insets(5, 5, 0, 5);
		gbc_txtValor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtValor.gridx = 0;
		gbc_txtValor.gridy = 3;
		txtValor.setComponenteNegrito(true);
		panelCampos.add(txtValor, gbc_txtValor);

		txtData.setRotulo("Data Registro");
		txtValor.setColunas(15);
		txtValor.setRotulo("Valor");
		txtValor.setFormato(Formato.MOEDA);
		
		GridBagConstraints gbc_txtDescricao = new GridBagConstraints();
		gbc_txtDescricao.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDescricao.weighty = 1.0;
		gbc_txtDescricao.insets = new Insets(5, 5, 0, 5);
		gbc_txtDescricao.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDescricao.gridx = 0;
		gbc_txtDescricao.gridy = 4;
		txtDescricao.setColunas(15);
		txtDescricao.setRotulo("Descrição");
		panelCampos.add(txtDescricao, gbc_txtDescricao);
		
		cmdSair.setText("Cancelar");
		
		cmdSalvar.setText("Confirmar");
		// Listners = Comandos = Eventos
		cmdSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				salvar();
			}
		});
		cmdSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sair();
			}
		});
		
		inicializa();
		
	}
	private void salvar() {
		try {
			entidade = new Lancamento();
			entidade.setValor(txtValor.getDouble());
			entidade.setDescricao(txtDescricao.getText());
			Conta conta = (Conta) cboConta.getValue();
			Natureza natureza = (Natureza) cboNatureza.getValue();
			entidade.setConta(conta.getId());
			
			entidade.setData(txtData.getDataHora());
			entidade.setNatureza(natureza.getId());
			entidade.setTipoMovimento(natureza.getTipoMovimento());
			entidade.setUsuario(getUsuarioId());
			
			if(entidade.getConta()==null || entidade.getNatureza() == null 
			|| entidade.getData() == null || entidade.getValor() == null || entidade.getDescricao()==null || entidade.getDescricao().isEmpty()) {
				Mensagem.avisa("Dados incompletos");
				return;
			}
			dao.incluirLancamento(entidade);
			Mensagem.informa("Lançamento registrado com sucesso!!");
			novo();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void novo() {
		if(chkNovo.isSelected()) {
			inicializa();
		}else
			super.retornar();
	}
	
	private void inicializa() {
		entidade = new Lancamento();
		txtData.requestFocus();
		txtData.setValue(new Date());
		txtValor.setValue(0.0d);
		txtData.setDataHora(new Date());
		txtDescricao.setText("");
	}
	private void sair() {
		super.fechar();
	}
	
	public void load() {
		List<Conta> contas = dao.listarContas(getUsuarioId());
		cboConta.setItens( contas,"nome");
		cboNatureza.setItens( dao.listarNaturezas(getUsuarioId(),TipoMovimento.CREDITO),"nomeSigla");	
	}
}
