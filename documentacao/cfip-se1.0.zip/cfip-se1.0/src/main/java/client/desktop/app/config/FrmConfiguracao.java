package client.desktop.app.config;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Usuario;
import com.boxs.cfip.core.util.Ambiente;

import client.desktop.DesktopApp;
import client.ss.desktop.Mensagem;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCabecalho;
import client.ss.desktop.SSCaixaCombinacao;
import client.ss.desktop.SSCampoSenha;
import client.ss.desktop.SSCampoTexto;
import client.ss.desktop.imagens.Imagem;
import client.ss.infraestrutura.util.Texto;
@Component
public class FrmConfiguracao extends JFrame {
	private JPanel content = new JPanel();
	private SSBotao cmdConfirmar = new SSBotao();
	private SSBotao cmdSair = new SSBotao();
	private Usuario entidade;
	@Autowired
	private Entidades dao;
	private JPanel form = new JPanel();
	private SSCaixaCombinacao cboAmbiente = new SSCaixaCombinacao();
	private JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private JPanel pnlWebservice = new JPanel();
	private Ambiente ambiente;
	private JPanel pnlLocal = new JPanel();
	private SSCampoTexto txtLogin = new SSCampoTexto();
	private SSCampoTexto txtEmail = new SSCampoTexto();
	private SSCampoSenha txtSenha = new SSCampoSenha();
	private SSCampoTexto txtNome = new SSCampoTexto();
	private SSCampoSenha txtRepeteSenha = new SSCampoSenha();
	private JPanel pnlServer = new JPanel();
	private SSCampoTexto txtDbLogin = new SSCampoTexto();
	private SSCampoSenha txtDbSenha = new SSCampoSenha();
	private SSCampoSenha txtDbRepeteSenha = new SSCampoSenha();
	private SSCampoTexto txtUrl = new SSCampoTexto();
	public FrmConfiguracao() {
		init();
	}
	private void init() {
		
		txtLogin.setTudoMaiusculo(false);
		txtEmail.setTudoMaiusculo(false);
		txtSenha.setTudoMaiusculo(false);
		txtRepeteSenha.setTudoMaiusculo(false);
		
		txtDbLogin.setTudoMaiusculo(false);
		txtDbSenha.setTudoMaiusculo(false);
		txtDbRepeteSenha.setTudoMaiusculo(false);
		txtUrl.setTudoMaiusculo(false);
		
		cboAmbiente.setItens(Ambiente.ambientes, "name");
		cboAmbiente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				definirAmbiente();
			}
		});
		
		setTitle("CFIP");
		this.setIconImage(Imagem.png("cfip", "janela").getImage());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(new Dimension(270, 430));
		setLocationRelativeTo(null);
		content.setBorder(new EmptyBorder(5, 5, 5, 5));
		content.setLayout(new BorderLayout(0, 0));
		setContentPane(content);

		SSCabecalho cabecalho = new SSCabecalho();
		cabecalho.setDescricao("Configuração inicial do ambiente");
		cabecalho.setTitulo("CFIP - CONFIGURAÇÃO");
		content.add(cabecalho, BorderLayout.NORTH);

		JPanel botoes = new JPanel();
		botoes.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		FlowLayout fl_botoes = (FlowLayout) botoes.getLayout();
		fl_botoes.setAlignment(FlowLayout.RIGHT);
		content.add(botoes, BorderLayout.SOUTH);
		cmdConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				confirmar();
			}
		});

		cmdConfirmar.setText("Confirmar");
		cmdConfirmar.setIcone("ok");

		botoes.add(cmdConfirmar);
		cmdSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fechar();

			}
		});

		cmdSair.setText("Sair");
		cmdSair.setIcone("fechar");
		botoes.add(cmdSair);
		form.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));

		content.add(form, BorderLayout.CENTER);
		GridBagLayout gbl_form = new GridBagLayout();
		form.setLayout(gbl_form);

		GridBagConstraints gbc_cboAmbiente = new GridBagConstraints();
		gbc_cboAmbiente.insets = new Insets(5, 5, 0, 5);
		gbc_cboAmbiente.anchor = GridBagConstraints.NORTHWEST;
		gbc_cboAmbiente.fill = GridBagConstraints.HORIZONTAL;
		gbc_cboAmbiente.gridx = 0;
		gbc_cboAmbiente.gridy = 0;
		cboAmbiente.setRotulo("Ambiente");
		form.add(cboAmbiente, gbc_cboAmbiente);

		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(5, 0, 5, 0);
		gbc_tabbedPane.weightx = 1.0;
		gbc_tabbedPane.anchor = GridBagConstraints.NORTHWEST;
		gbc_tabbedPane.weighty = 1.0;
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		form.add(tabbedPane, gbc_tabbedPane);
		
		pnlLocal.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));

		GridBagLayout gbl_pnlLocal = new GridBagLayout();
		pnlLocal.setLayout(gbl_pnlLocal);

		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNome.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtNome.insets = new Insets(0, 5, 0, 5);
		gbc_txtNome.gridx = 0;
		gbc_txtNome.gridy = 0;
		
		txtNome.setText("Nome Sobrenome");
		txtNome.setRotulo("Nome");
		pnlLocal.add(txtNome, gbc_txtNome);

		GridBagConstraints gbc_txtLogin = new GridBagConstraints();
		gbc_txtLogin.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLogin.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtLogin.insets = new Insets(5, 5, 0, 5);
		gbc_txtLogin.gridx = 0;
		gbc_txtLogin.gridy = 1;
		
		txtLogin.setText("login");
		txtLogin.setRotulo("Login");
		pnlLocal.add(txtLogin, gbc_txtLogin);

		GridBagConstraints gbc_txtEmail = new GridBagConstraints();
		gbc_txtEmail.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtEmail.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtEmail.insets = new Insets(5, 5, 0, 5);
		gbc_txtEmail.gridx = 0;
		gbc_txtEmail.gridy = 2;
		
		txtEmail.setTudoMaiusculo(false);
		txtEmail.setText("email@email.com");
		txtEmail.setRotulo("E-mail");
		txtEmail.setColunas(10);
		pnlLocal.add(txtEmail, gbc_txtEmail);

		GridBagConstraints gbc_txtSenha = new GridBagConstraints();
		gbc_txtSenha.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtSenha.anchor = GridBagConstraints.NORTHEAST;
		gbc_txtSenha.insets = new Insets(5, 5, 0, 5);
		gbc_txtSenha.gridx = 0;
		gbc_txtSenha.gridy = 3;
		
		txtLogin.setTudoMaiusculo(false);
		txtSenha.setTudoMaiusculo(false);
		txtSenha.setText("1234");
		txtSenha.setRotulo("Senha  (1234)");
		pnlLocal.add(txtSenha, gbc_txtSenha);

		GridBagConstraints gbc_txtRepeteSenha = new GridBagConstraints();
		gbc_txtRepeteSenha.weighty = 1.0;
		gbc_txtRepeteSenha.weightx = 1.0;
		gbc_txtRepeteSenha.insets = new Insets(5, 5, 5, 5);
		gbc_txtRepeteSenha.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtRepeteSenha.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtRepeteSenha.gridx = 0;
		gbc_txtRepeteSenha.gridy = 4;
		
		txtRepeteSenha.setText("1234");
		txtRepeteSenha.setRotulo("Repete Senha");
		pnlLocal.add(txtRepeteSenha, gbc_txtRepeteSenha);
		pnlServer.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));

		
		GridBagLayout gbl_pnlServer = new GridBagLayout();
		pnlServer.setLayout(gbl_pnlServer);

		GridBagConstraints gbc_txtUrl = new GridBagConstraints();
		gbc_txtUrl.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtUrl.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtUrl.insets = new Insets(0, 5, 0, 5);
		gbc_txtUrl.gridx = 0;
		gbc_txtUrl.gridy = 0;
		
		txtUrl.setRotulo("URL");
		pnlServer.add(txtUrl, gbc_txtUrl);

		GridBagConstraints gbc_txtDbLogin = new GridBagConstraints();
		gbc_txtDbLogin.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDbLogin.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDbLogin.insets = new Insets(5, 5, 0, 5);
		gbc_txtDbLogin.gridx = 0;
		gbc_txtDbLogin.gridy = 1;
		
		txtDbLogin.setRotulo("Usuário do banco de dados");
		pnlServer.add(txtDbLogin, gbc_txtDbLogin);

		GridBagConstraints gbc_txtDbSenha = new GridBagConstraints();
		gbc_txtDbSenha.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDbSenha.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDbSenha.insets = new Insets(5, 5, 0, 5);
		gbc_txtDbSenha.gridx = 0;
		gbc_txtDbSenha.gridy = 2;
		
		txtDbSenha.setTudoMaiusculo(false);
		
		txtDbSenha.setRotulo("Senha do banco de dados");
		txtDbSenha.setColunas(10);
		pnlServer.add(txtDbSenha, gbc_txtDbSenha);

		GridBagConstraints gbc_txtDbRepeteSenha = new GridBagConstraints();
		gbc_txtDbRepeteSenha.weighty = 1.0;
		gbc_txtDbRepeteSenha.weightx = 1.0;
		gbc_txtDbRepeteSenha.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDbRepeteSenha.anchor = GridBagConstraints.NORTHEAST;
		gbc_txtDbRepeteSenha.insets = new Insets(5, 5, 0, 5);
		gbc_txtDbRepeteSenha.gridx = 0;
		gbc_txtDbRepeteSenha.gridy = 3;
		
		txtDbRepeteSenha.setTudoMaiusculo(false);
		
		txtDbRepeteSenha.setRotulo("Senha");
		pnlServer.add(txtDbRepeteSenha, gbc_txtDbRepeteSenha);
		tabbedPane.addTab("LOCAL", null, pnlLocal, null);
		//cboAmbiente.setEditavel(false);
	}
	public void setParametros(Usuario entidade,String ambiente) {
		this.entidade = entidade;
		exibir(ambiente);
	}
	private void exibir(String ambiente) {
		if("LOCAL".equals(ambiente))
			cboAmbiente.setValue(Ambiente.LOCAL);
		else
			cboAmbiente.setValue(Ambiente.SERVER);
		definirAmbiente();
		if (entidade!= null) {
			txtLogin.setText(entidade.getLogin());
			txtEmail.setText(entidade.getEmail());
			txtNome.setText(entidade.getNome());
			txtLogin.setEditavel(false);
			txtEmail.setEditavel(false);
			txtNome.setEditavel(false);
			txtSenha.setEditavel(false);
			txtRepeteSenha.setEditavel(false);
			txtSenha.setText("");
			txtRepeteSenha.setText("");
			
		}	
	}
	private void definirAmbiente() {
		ambiente = (Ambiente) cboAmbiente.getValue();
		tabbedPane.removeAll();
		if (ambiente != null) {
			if (ambiente == Ambiente.LOCAL)
				tabbedPane.addTab("Local", null, pnlLocal, null);
			else if (ambiente == Ambiente.SERVER) {
				tabbedPane.addTab("Server", null, pnlServer, null);
				txtUrl.setText(ambiente.getDbUrl());
				txtDbLogin.setText(ambiente.getDbUser());
				txtDbSenha.setText(ambiente.getDbPass());
				txtDbRepeteSenha.setText(ambiente.getDbPass());
			}
		}
	}

	private void confirmar() {
		try {
			if (ambiente == Ambiente.LOCAL) {
				configuracaoLocal();
			}else if (ambiente == Ambiente.SERVER) {
				configuracaoServer();
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}

	}
	private void configuracaoLocal() throws Exception{
		if(entidade==null || entidade.getId()==null) {
			if(txtNome.getText()==null || txtNome.getText().trim().isEmpty()){
				Mensagem.avisa("Informe um nome");
				return;
			}
			if(txtEmail.getText()==null || txtEmail.getText().trim().isEmpty()){
				Mensagem.avisa("Informe um e-mail");
				return;
			}
			if(txtLogin.getText()==null || txtLogin.getText().trim().isEmpty()){
				Mensagem.avisa("Informe um usuário");
				return;
			}
			if(txtSenha.getText()==null || txtSenha.getText().trim().isEmpty()){
				Mensagem.avisa("Informe a senha do usuário");
				return ;
			}
			if(!txtSenha.getSenha().equals(txtRepeteSenha.getSenha())){
				Mensagem.avisa("Senhas não conferem");
				return;
			}
			entidade = new Usuario();
		}
		if(!Mensagem.pergunta("Concluir a configuração atual")){
			return;
		}
		entidade.setEmail(txtEmail.getText());
		entidade.setNome(txtNome.getText());
		entidade.setSenha(Texto.md5(txtSenha.getText()));
		entidade.setLogin(txtLogin.getText());
		if (entidade.getId() == null) {
			if (!dao.contaUnica(entidade.getLogin(), entidade.getEmail())) {
				Mensagem.avisa("O usuário " + entidade.getLogin() + ":" + entidade.getEmail() + " Já está cadastrado");
				return;
			}
			dao.incluirUsuario(entidade);
			Mensagem.informa("Usuario registrado com sucesso\nAcesse o sistema");
		}
		
		ambiente.setStatus("OK");
		DesktopApp.configurarAmbiente(ambiente);
		Mensagem.informa("Acesse o sistema com as novas configurações");
		fechar();
	}
	private void configuracaoServer() throws Exception{
		if(txtUrl.getText()==null || txtUrl.getText().trim().isEmpty()){
			Mensagem.avisa("Informe uma URL");
			return ;
		}
		if(txtDbLogin.getText()==null || txtDbLogin.getText().trim().isEmpty()){
			Mensagem.avisa("Informe o usuário do banco de dados");
			return ;
		}
		if(txtDbSenha.getText()==null || txtDbSenha.getText().trim().isEmpty()){
			Mensagem.avisa("Informe a senha do banco de dados");
			return ;
		}
		if(!txtDbSenha.getText().equals(txtDbRepeteSenha.getSenha())){
			Mensagem.avisa("Senhas não conferem");
			return; 
		}
		if(!Mensagem.pergunta("Concluir a configuração atual")){
			return;
		}
		
		ambiente.setDbUrl(txtUrl.getText());
		ambiente.setDbUser(txtDbLogin.getText());
		ambiente.setDbPass(txtDbSenha.getText());
		ambiente.setStatus("OK");
		DesktopApp.configurarAmbiente(ambiente);
		Mensagem.informa("Acesse o sistema com as novas configurações");
		fechar();
		
	}
	
	private void fechar() {
		System.exit(0);
	}
}
