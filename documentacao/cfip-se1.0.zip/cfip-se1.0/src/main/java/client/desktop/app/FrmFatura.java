package client.desktop.app;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Fatura;
import com.boxs.cfip.core.model.Contato;
import com.boxs.cfip.core.util.Formato;
import com.boxs.cfip.core.util.TipoOperacao;

import client.desktop.util.Formulario;
import client.ss.desktop.Mensagem;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCampoDataHora;
import client.ss.desktop.SSCampoNumero;
import client.ss.desktop.SSCampoTexto;
import client.ss.infraestrutura.util.Validacao;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FrmFatura extends Formulario {
	private SSCampoDataHora txtVencimento = new SSCampoDataHora();
	private SSCampoTexto txtNome = new SSCampoTexto();
	private SSCampoTexto txtDetalhe = new SSCampoTexto();
	private JCheckBox chkFechada = new JCheckBox("Fechada?");

	private SSBotao cmdSalvar = new SSBotao();
	private SSBotao cmdSair = new SSBotao();
	private Fatura entidade;
	private TipoOperacao operacao;
	@Autowired
	private Entidades dao;
	private JCheckBox chkNovo = new JCheckBox("Novo?");
	public FrmFatura() {
		init();
	}
	private void init() {
		// HERANÇA
		super.setTitulo("Cadastro de Faturas");
		super.setDescricao("Registro de fatura ou lote de pagamentos");
		super.addComponente(chkNovo);
		super.addBotaoRodape(cmdSalvar);
		super.addBotaoRodape(cmdSair);
		// IMPORTANTE
		JPanel panelCampos = super.getConteudoGrid();
		panelCampos.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		GridBagLayout gbl_panelCampos = new GridBagLayout();
		panelCampos.setLayout(gbl_panelCampos);

		
		GridBagConstraints gbcTxtNome = new GridBagConstraints();
		gbcTxtNome.anchor = GridBagConstraints.NORTHWEST;
		gbcTxtNome.weightx = 2.0;
		gbcTxtNome.insets = new Insets(5, 5, 0, 0);
		gbcTxtNome.fill = GridBagConstraints.HORIZONTAL;
		gbcTxtNome.gridx = 0;
		gbcTxtNome.gridy = 0;
		txtVencimento.setColunas(8);
		panelCampos.add(txtVencimento, gbcTxtNome);
		
		GridBagConstraints gbcChkFechada = new GridBagConstraints();
		gbcChkFechada.insets = new Insets(15, 5, 0, 5);
		gbcChkFechada.fill = GridBagConstraints.HORIZONTAL;
		gbcChkFechada.gridx = 2;
		gbcChkFechada.gridy = 0;
		panelCampos.add(chkFechada, gbcChkFechada);

		txtVencimento.setRotulo("Vencimento");

		GridBagConstraints gbc_txtDescricao = new GridBagConstraints();
		gbc_txtDescricao.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDescricao.insets = new Insets(5, 5, 0, 5);
		gbc_txtDescricao.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDescricao.gridx = 1;
		gbc_txtDescricao.gridy = 0;
		txtNome.setColunas(8);
		txtNome.setRotulo("Sigla");
		panelCampos.add(txtNome, gbc_txtDescricao);

		GridBagConstraints gbc_saldoInicial = new GridBagConstraints();
		gbc_saldoInicial.gridwidth = 3;
		gbc_saldoInicial.weightx = 1.0;
		gbc_saldoInicial.weighty = 1.0;
		gbc_saldoInicial.anchor = GridBagConstraints.NORTHWEST;
		gbc_saldoInicial.insets = new Insets(5, 5, 5, 5);
		gbc_saldoInicial.fill = GridBagConstraints.HORIZONTAL;
		gbc_saldoInicial.gridx = 0;
		gbc_saldoInicial.gridy = 1;
		txtDetalhe.setForeground(Color.BLACK);
		txtDetalhe.setRotulo("Detalhe");
		panelCampos.add(txtDetalhe, gbc_saldoInicial);

		cmdSair.setText("Fechar");
		cmdSalvar.setText("Salvar");

		// Listners = Comandos = Eventos
		cmdSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				salvar();
			}
		});
		cmdSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sair();
			}
		});
		chkFechada.setEnabled(false);
	}

	public void setEntidade(Fatura entidade) {
		this.entidade = entidade;
		if (entidade != null)
			operacao = TipoOperacao.ALTERACAO;
		else
			criar();
		
		atribuir();
	}
	private void atribuir() {
		try {
			txtVencimento.setValue(entidade.getVencimento());
			txtNome.setText(entidade.getSigla());
			txtDetalhe.setValue(entidade.getDetalhe());
			chkFechada.setSelected(entidade.isFechada());
			txtVencimento.requestFocus();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}
	private void criar() {
		operacao = TipoOperacao.INCLUSAO;
		entidade = new Fatura();
		atribuir();
	}
	private void salvar() {
		try {
			if (entidade == null) {
				entidade = new Fatura();
			}
			entidade.setSigla(txtNome.getText());
			entidade.setDetalhe(txtDetalhe.getText());
			entidade.setVencimento(txtVencimento.getDataHora());
			entidade.setFechada(chkFechada.isSelected());
			entidade.setUsuario(getUsuarioId());

			if (entidade.getSigla() == null || entidade.getSigla().isEmpty() || entidade.getDetalhe() == null
					|| entidade.getDetalhe().isEmpty() 
					|| entidade.getVencimento() == null) {
				Mensagem.avisa("Dados incompletos");
				return;
			}
			dao.gravar(operacao, entidade);
			Mensagem.informa("Fatura registrado com sucesso!!");
			novo();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}
	private void novo() {
		if(chkNovo.isSelected()) {
			criar();
		}else
			super.retornar();
	}
	private void sair() {
		super.fechar();
	}
	public void load(Object param) {
	}
}
