package client.desktop.app;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.function.Supplier;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Contato;
import com.boxs.cfip.core.util.TipoOperacao;

import client.desktop.util.Formulario;
import client.ss.desktop.Mensagem;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCampoTexto;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)	
public class FrmContato extends Formulario {
	private SSCampoTexto txtNome = new SSCampoTexto();
	private SSCampoTexto txtTelefone = new SSCampoTexto();
	private SSCampoTexto txtId = new SSCampoTexto();

	private SSBotao cmdSalvar = new SSBotao();
	private SSBotao cmdSair = new SSBotao();
	private Contato entidade;
	private TipoOperacao operacao;
	@Autowired
	private Entidades dao;
	private JCheckBox chkNovo = new JCheckBox("Novo?");

	public FrmContato() {
		init();
	}
	
	private void init() {
		txtId.setComponenteNegrito(true);
		txtId.setComponenteCorFonte(Color.BLUE);
		txtId.setColunas(5);
		txtId.setEditavel(false);
		// HERANÇA
		super.setTitulo("Cadastro de Contato");
		super.setDescricao("Registro dos Clientes e Fornecedores");
		super.addComponente(chkNovo);
		super.addBotaoRodape(cmdSalvar);
		super.addBotaoRodape(cmdSair);
		// IMPORTANTE
		JPanel panelCampos = super.getConteudoGrid();
		panelCampos.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		GridBagLayout gbl_panelCampos = new GridBagLayout();
		panelCampos.setLayout(gbl_panelCampos);

		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.weightx = 1.0;
		gbc_txtNome.gridwidth = 2;
		gbc_txtNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNome.anchor = GridBagConstraints.WEST;
		gbc_txtNome.insets = new Insets(5, 5, 0, 5);
		gbc_txtNome.gridx = 0;
		gbc_txtNome.gridy = 0;
		panelCampos.add(txtNome, gbc_txtNome);
		txtNome.setColunas(5);

		GridBagConstraints gbc_txtTelefone = new GridBagConstraints();
		gbc_txtTelefone.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtTelefone.weighty = 1.0;
		gbc_txtTelefone.insets = new Insets(5, 5, 0, 5);
		gbc_txtTelefone.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtTelefone.gridx = 0;
		gbc_txtTelefone.gridy = 1;
		panelCampos.add(txtTelefone, gbc_txtTelefone);

		txtNome.setRotulo("Nome");
		txtTelefone.setColunas(30);
		txtTelefone.setRotulo("Telefone");
		
		GridBagConstraints gbc_txtId = new GridBagConstraints();
		gbc_txtId.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtId.weighty = 1.0;
		gbc_txtId.insets = new Insets(5, 5, 0, 5);
		gbc_txtId.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtId.gridx = 1;
		gbc_txtId.gridy = 1;
		txtId.setRotulo("ID");
		panelCampos.add(txtId, gbc_txtId);
		
		
		cmdSair.setText("Fechar");
		cmdSalvar.setText("Salvar");

		// Listners = Comandos = Eventos
		cmdSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				salvar();
			}
		});
		cmdSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sair();
			}
		});
		
	}
	public void setEntidade(Contato entidade) {
		this.entidade = entidade;
		if (entidade != null)
			operacao = TipoOperacao.ALTERACAO;
		else
			criar();
		
		atribuir();
	}
	private void atribuir() {
		try {
			txtNome.setValue(entidade.getNome());
			txtId.setValue(entidade.getId());
			txtTelefone.setText(entidade.getTelefone());
			txtNome.requestFocus();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}
	private void criar() {
		operacao = TipoOperacao.INCLUSAO;
		entidade = new Contato();
		atribuir();
	}
	private void salvar() {
		try {
			if (entidade == null) {
				entidade = new Contato();
			}
			entidade.setNome(txtNome.getText());
			entidade.setTelefone(txtTelefone.getText());
			entidade.setUsuario(getUsuarioId());
			
			if (entidade.getNome() == null || entidade.getNome().isEmpty() || entidade.getTelefone() == null
					|| entidade.getTelefone().isEmpty()) {
				Mensagem.avisa("Dados incompletos");
				return;
			}
			dao.gravar(operacao, entidade);
			Mensagem.informa("Contato registrado com sucesso!!");
			novo();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}
	private void novo() {
		if(chkNovo.isSelected()) {
			criar();
		}else
			super.retornar();
	}
	private void sair() {
		super.fechar();
	}
	public void load(Object param) {}
}
	