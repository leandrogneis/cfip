package client.desktop.app;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Date;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Conta;
import com.boxs.cfip.core.model.Lancamento;
import com.boxs.cfip.core.model.Natureza;
import com.boxs.cfip.core.model.TipoMovimento;
import com.boxs.cfip.core.util.Formato;
import com.boxs.cfip.core.util.TipoOperacao;

import client.desktop.util.Formulario;
import client.ss.desktop.Mensagem;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCaixaCombinacao;
import client.ss.desktop.SSCampoDataHora;
import client.ss.desktop.SSCampoNumero;
import client.ss.desktop.SSCampoTexto;
import javax.swing.ScrollPaneConstants;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)	
public class FrmCompensar extends Formulario {
	private SSCampoDataHora txtData = new SSCampoDataHora();
	private SSCampoNumero txtValor = new SSCampoNumero();
	private JTextArea txtDescricao = new JTextArea();
	
	private SSBotao cmdSalvar = new SSBotao();
	private SSBotao cmdSair = new SSBotao();
	private Lancamento entidade;
	@Autowired
	private Entidades dao;
	
	public FrmCompensar() {
		init();
	}
	private void init() {
		// HERANÇA
		super.setTitulo("Compensação");
		super.setDescricao("Compensa Previsão");
		super.addBotaoRodape(cmdSalvar);
		super.addBotaoRodape(cmdSair);
		// IMPORTANTE
		JPanel panelCampos = super.getConteudoGrid();
		panelCampos.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		GridBagLayout gbl_panelCampos = new GridBagLayout();
		panelCampos.setLayout(gbl_panelCampos);

		GridBagConstraints gbc_txtData = new GridBagConstraints();
		gbc_txtData.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtData.anchor = GridBagConstraints.WEST;
		gbc_txtData.insets = new Insets(5, 5, 0, 5);
		gbc_txtData.gridx = 0;
		gbc_txtData.gridy = 0;
		txtData.setColunas(10);
		txtData.setComponenteCorFonte(Color.BLUE);
		txtData.setComponenteNegrito(true);
		txtData.setForeground(Color.BLUE);
		panelCampos.add(txtData, gbc_txtData);

		GridBagConstraints gbc_txtValor = new GridBagConstraints();
		gbc_txtValor.weightx = 2.0;
		gbc_txtValor.insets = new Insets(5, 5, 0, 5);
		gbc_txtValor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtValor.gridx = 0;
		gbc_txtValor.gridy = 1;
		txtValor.setEditavel(false);
		txtValor.setComponenteCorFonte(Color.BLUE);
		txtValor.setComponenteNegrito(true);
		panelCampos.add(txtValor, gbc_txtValor);

		txtData.setRotulo("Data");
		txtValor.setColunas(10);
		txtValor.setRotulo("Valor");
		txtValor.setFormato(Formato.MOEDA);
		
		GridBagConstraints gbc_txtDescricao = new GridBagConstraints();
		gbc_txtDescricao.anchor = GridBagConstraints.NORTHWEST;
		gbc_txtDescricao.weighty = 1.0;
		gbc_txtDescricao.insets = new Insets(5, 5, 0, 5);
		gbc_txtDescricao.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDescricao.gridx = 0;
		gbc_txtDescricao.gridy = 2;
		txtDescricao.setLineWrap(true);
		txtDescricao.setColumns(20);
		txtDescricao.setRows(4);
		txtDescricao.setWrapStyleWord(true);
		//txtDescricao.setEnabled(false);
		txtDescricao.setText("DESCRIÇÃO");
		txtDescricao.setForeground(Color.BLUE);
		JScrollPane scrooll = new JScrollPane(txtDescricao);
		scrooll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		panelCampos.add(scrooll, gbc_txtDescricao);
		
		
		cmdSair.setText("Cancelar");
		cmdSalvar.setText("Confirmar");
		
		// Listners = Comandos = Eventos
		cmdSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				salvar();
			}
		});
		cmdSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sair();
			}
		});
		txtData.requestFocus();
		txtData.setValue(new Date());
		txtValor.setValue(0.0d);
	}
	private void salvar() {
		if(Mensagem.pergunta("Confirma compensar este lançamento ?")) {
			dao.compensarLancamento(entidade.getId(),txtData.getDataHora());
			Mensagem.informa("Lançamento compensado com sucesso!!");
			super.retornar();
		}
		
	}
	public void setId(Integer id) {
		entidade = dao.buscar(Lancamento.class, id);
		if(entidade!=null) {
			txtData.setDataHora(new Date());
			txtValor.setRotulo(entidade.getTipoMovimento() + " - R$ Valor");
			txtValor.setValue(entidade.getValor());
			txtDescricao.setText(entidade.getTipoMovimento() + "\n" + entidade.getDescricao());
			if(entidade.getTipoMovimento() == TipoMovimento.DEBITO) {
				txtData.setComponenteCorFonte(Color.RED);
				txtValor.setComponenteCorFonte(Color.RED);
				txtDescricao.setForeground(Color.RED);
			}
		}
	}
	private void sair() {
		super.fechar();
	}
	
}
