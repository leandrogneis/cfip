package client.desktop.app;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.boxs.cfip.core.dao.Entidades;
import com.boxs.cfip.core.model.Conta;
import com.boxs.cfip.core.model.Saldo;

import client.desktop.util.Formulario;
import client.ss.desktop.Mensagem;
import client.ss.desktop.SSBotao;
import client.ss.desktop.SSCaixaCombinacao;
import client.ss.desktop.SSCampoDataHora;
import client.ss.desktop.SSCampoNumero;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FrmSaldo extends Formulario {
	private SSCaixaCombinacao cboConta = new SSCaixaCombinacao();
	private SSCampoDataHora txtData = new SSCampoDataHora();
	private SSCampoNumero txtValor = new SSCampoNumero();

	private SSBotao cmdSalvar = new SSBotao();
	private SSBotao cmdSair = new SSBotao();
	@Autowired
	private Entidades dao;
	
	public FrmSaldo() {
		init();
	}

	private void init() {
		// HERANÇA
		super.setTitulo("Cadastro de Naturezas");
		super.setDescricao("Descrição das Entradas e Saidas");
		super.addBotaoRodape(cmdSalvar);
		super.addBotaoRodape(cmdSair);
		// IMPORTANTE
		JPanel panelCampos = super.getConteudoGrid();
		panelCampos.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		GridBagLayout gbl_panelCampos = new GridBagLayout();
		panelCampos.setLayout(gbl_panelCampos);

		GridBagConstraints gbcCboConta = new GridBagConstraints();
		gbcCboConta.weightx = 2.0;
		gbcCboConta.insets = new Insets(5, 5, 0, 5);
		gbcCboConta.fill = GridBagConstraints.HORIZONTAL;
		gbcCboConta.gridx = 0;
		gbcCboConta.gridy = 0;
		cboConta.setRotulo("Conta");
		panelCampos.add(cboConta, gbcCboConta);
		
		GridBagConstraints gbcData = new GridBagConstraints();
		gbcData.fill = GridBagConstraints.HORIZONTAL;
		gbcData.anchor = GridBagConstraints.WEST;
		gbcData.insets = new Insets(5, 5, 5, 5);
		gbcData.gridx = 0;
		gbcData.gridy = 2;
		panelCampos.add(txtData, gbcData);
		txtData.setColunas(5);

		GridBagConstraints gbcValor = new GridBagConstraints();
		gbcValor.weightx = 2.0;
		gbcValor.insets = new Insets(5, 5, 0, 5);
		gbcValor.fill = GridBagConstraints.HORIZONTAL;
		gbcValor.gridx = 0;
		gbcValor.gridy = 1;
		panelCampos.add(txtValor, gbcValor);
		txtValor.setEditavel(false);
		txtData.setRotulo("Data");
		txtValor.setColunas(30);
		txtValor.setRotulo("Valor");

		cmdSair.setText("Fechar");
		cmdSalvar.setText("Salvar");

		// Listners = Comandos = Eventos
		cmdSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				salvar();
			}
		});
		cmdSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sair();
			}
		});
		cboConta.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		       mostrarValor();
		    }
		});

	}
	public void load() {
		cboConta.setItens(dao.listarContas(getUsuarioId()),"nome");
		txtData.setValue(new Date());
	}
	private void mostrarValor() {
		Conta conta = (Conta) cboConta.getValue();
		txtValor.setValue(0.0d);
		if(conta!=null)
			txtValor.setValue(conta.getSaldo());
	}
	private void salvar() {
		try {
			Conta conta = (Conta) cboConta.getValue();
			if(conta!=null) {
				Saldo entidade = new Saldo();
				entidade.setConta(conta);
				entidade.setData(txtData.getDataHora());;
				entidade.setValor(txtValor.getDouble());
				conta.setSaldoInicial(entidade);

			}else
				Mensagem.avisa("Selecione uma Conta");
				dao.alterar(conta);
			Mensagem.informa("Saldo registrado com sucesso!!");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void sair() {
		super.fechar();
	}

}
